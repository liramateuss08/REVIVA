import threading
import time

def tarefa_1():
    print("Tarefa 1 iniciada.")
    time.sleep(3)  # Simula uma espera de 3 segundos
    print("Tarefa 1 concluída!")

def tarefa_2():
    print("Tarefa 2 iniciada.")
    time.sleep(1)  # Simula uma espera de 1 segundo
    print("Tarefa 2 concluída!")

# 1. Criar as instâncias das threads apontando para as funções
thread_a = threading.Thread(target=tarefa_1)
thread_b = threading.Thread(target=tarefa_2)

# 2. Iniciar a execução das threads em segundo plano
thread_a.start()
thread_b.start()

# 3. Aguardar que ambas terminem antes de seguir com o script principal
thread_a.join()
thread_b.join()

print("Todas as tarefas foram finalizadas com sucesso!")